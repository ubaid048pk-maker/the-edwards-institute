THE EDWARDS INSTITUTE WEBSITE
==============================

Files:
- index.html  -> main website
- style.css   -> design and responsive layout
- script.js   -> mobile navigation

How to use:
1. Keep all three files in the same folder.
2. Double-click index.html to preview the website.
3. To publish it online, upload the files to any web hosting service.

Academy details used:
The Edwards Institute
Location: Ishrat Cinema Chowk, next to TKS School, Peshawar
Phone: 0333-3382288

Note: Course timings, fees, admission dates, email, social media, logo, photos, and exact address can be added later.
